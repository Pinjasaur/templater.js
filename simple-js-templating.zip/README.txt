A Pen created at CodePen.io. You can find this one at http://codepen.io/Pinjasaur/pen/XKXoor.

 Simple JavaScript templating inspired by: 
http://jsforallof.us/2014/12/01/the-anatomy-of-a-simple-templating-engine/
http://krasimirtsonev.com/blog/article/Javascript-template-engine-in-just-20-line

Very simple, just does a find and replace and an if condition to conditionally show the markup if the property exists in the data.